# AUTHORS

The tutorial materials are primarily based on the contents of two other
workshops, the [Oxford Computational Biochemistry Python Course](https://github.com/bigginlab/OxCompBio/tree/master/tutorials/Python)
and [The Carpentries “Programming with Python” workshop](https://swcarpentry.github.io/python-novice-inflammation/).
We thank and acknowledge the contributions of the authors from both of these workshops.

Below is a list of direct contributors to this tutorial by year.

## 2022
- Irfan Alibay (@IAlibay)

